function check(){

    var reponse=0; 
    var q1=document.quizz.question1.value;
    var q2=document.quizz.question2.value; 
    var q3=document.quizz.question3.value;
    var q4=document.quizz.question4.value; 
    var q5=document.quizz.question5.value; 
    var q6=document.quizz.question6.value; 
    var q7=document.quizz.question7.value; 

    if(q1=="VRAI")
    {
        reponse++;
    }

    if(q2=="VRAI")
    {
        reponse++;
    }

    if(q3=="VRAI")
    {
        reponse++;
    }

    if(q4=="VRAI")
    {
        reponse++;
    }

    if(q5=="VRAI")
    {
        reponse++;
    }

    if(q6=="VRAI")
    {
        reponse++;
    }

    if(q7=="VRAI")
    {
        reponse++;
    }

    if(reponse<=7 && reponse>=6)
    {
        alert(" 😆 Tu es un(e) veritable ARMY bravo tu as eu au moins 6 reponses juste. Bts n'a plus de secret pour toi, tu merites ta place de concert!!")
    }

    if(reponse<6 && reponse>=4)
    {
        alert(" 😉 Bravo tu t'en sort super bien tu as eu au moins 4 bonne reponse tu es un(e) ARMY confirmé !! ")
    }

    if(reponse<4)
    {
        alert(" 😊 Ohh ne serrais tu pas un(e) baby ARMY bienvenue!! N'hesite pas à lire les paroles pour en savoir plus sur les garcons ;-)")
    }
}
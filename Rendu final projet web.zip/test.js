//fonction getResults pour récupérer les résultats de l'utilisateur et incrémenter les compteurs relié aux 4 maisons
function getResults()
{
    var pouf=0;
    var serp=0;
    var gryf =0;
    var serd=0;
    for(let maison of document.querySelectorAll("input:checked")) 
    {
        console.log(maison.value);
        if(maison.value==="pouf") 
        {
            pouf++;
        }
        else if (maison.value==="serd")
        {
            serd++;
        }
        else if (maison.value==="gryf")
        {
            gryf++;
        }
        else 
        {
            serp++;
        }
    }
    //permet d'afficher le message du résultat
    var maison= getMaison(pouf, serp, gryf, serd);
    alert("hmm je vois... je vois "+maison);
    return false;
}

//fonction pour determiner où il y a le plus de points et renvoie la fin du message du résultat
function getMaison(pouf, serp, gryf, serd)
{
    if (pouf > serp && pouf > serd && pouf> gryf) 
    {
        return "quelqu'un de juste et loyal. Poufsouffle! ";
    }
    else if (gryf>serp && gryf> serd && gryf>pouf) 
    {
        return "quelqu'un de fort et de courageux. Gryffondor!";
    }
    else if (serp > serd && serp >gryf && serp >pouf) 
    {
        return "quelqu'un de rusé et d'ambitieux. Serpentard!";
    }
    else if(serd>serp && serd>gryf && sred>pouf)
    {
        return " quelqu'un de sage et réfléchi. Serdaigle!";
    }
    else if(gryf===pouf && gryf>serd && gryf>serp ) 
    {
        return "quelqu'un d'aussi loyal que courageux. Je ne saurais me décider entre Gryffondor et Poufsouffle.";
    }
    else if (gryf===serd && gryf >pouf && gryf >serp) 
    {
        return "quelqu'un d'aussi courageux que sage. Je ne saurais me décider entre Gryffondor et Serdaigle.";
    }
    else if (gryf===serp && gryf > serd && gryf> pouf) 
    {
        return "quelqu'un d'aussi courageux qu'ambitieux. Je ne saurais me décider entre Gryffondor et Serpentard.";
    }
    else if (pouf===serd && pouf > gryf && pouf > serp) 
    {
        return "quelqu'un d'aussi loyal que sage. Je ne saurais me décider entre Poufsouffle et Serdaigle.";
    }
    else if (pouf === serp && pouf >gryf && pouf >serd) 
    {
        return "quelqu'un d'aussi loyal qu'ambitieux. Je ne saurais me décider entre Poufsouffle et Serpentard.";
    }
    else if (serd===serp && serd>gryf && serd>pouf) 
    {
        return "quelqu'un d'aussi sage qu'ambitieux. Je ne saurais me décider entre Serdaigle et Serpentard.";
    }
    else if(gryf===serp && gryf===serd && gryf>pouf) 
    {
        return "quelqu'un de courageux, d'ambitieux et de sage. Je ne peux pas me décider entre Gryffondor, Serpentard et Serdaigle.";
    }
    else if(gryf===serp && gryf===pouf && gryf>serd)
    {
        return "quelqu'un de courageux, d'ambitieux et de loyal. Je ne peux pas me décider entre Gryffondor, Serpentard et Poufsouffle.";
    }
    else if (gryf===pouf && gryf===serd && gryf >serp)
    {
        return "quelqu'un de courageux, de loyal et de sage. Je ne peux pas me décider entre Gryffondor, Poufsouffle et Serdaigle.";
    }
    else if(serp===serd && serp===pouf && serp>gryf)
    {
        return "quelqu'un de loyal, d'ambitieux et de sage. Je ne peux pas me décider entre Poufsouffle, Serpentard et Serdaigle.";
    }
}
function check()
{

    var tabreponse= [0,0,0,0,0,0,0]
    var q1=document.quizz.question1.value;
    var q2=document.quizz.question2.value; 
    var q3=document.quizz.question3.value;
    var q4=document.quizz.question4.value; 
    var q5=document.quizz.question5.value; 
    var q6=document.quizz.question6.value; 
    var q7=document.quizz.question7.value; 


    switch (q1)
    {
        case "NAMJOON": 
            tabreponse[0]++; 
            break; 

        case "JIN": 
            tabreponse[1]++;
         
            break; 
        
        case "YOONGI": 
            tabreponse[2]++; 
            break; 
        
        case "JUNGKOOK":
            tabreponse[6]++; 
            break; 
        
        default: 
            console.log("Selectionner une reponse"); 

    }

    switch (q2)
    {
        case "JIMIN": 
            tabreponse[4]++; 
            break; 

        case "NAMJOON": 
            tabreponse[0]++;
         
            break; 
        
        case "YOONGI": 
            tabreponse[2]++; 
            break; 
        
        case "TAEHYUNG":
            tabreponse[5]++; 
            break; 
        
        default: 
            console.log("Selectionner une reponse"); 

    }
    switch (q3)
    {
        case "JHOPE": 
            tabreponse[3]++; 
            break; 

        case "TAEHYUNG": 
            tabreponse[5]++;
         
            break; 
        
        case "JUNGKOOK": 
            tabreponse[6]++; 
            break; 
        
        case "NAMJOON":
            tabreponse[0]++; 
            break; 
        
        default: 
            console.log("Selectionner une reponse"); 

    }
    switch (q4)
    {
        case "JIN": 
            tabreponse[1]++; 
            break; 

        case "JHOPE": 
            tabreponse[3]++;
         
            break; 
        
        case "YOONGI": 
            tabreponse[2]++; 
            break; 
        
        case "JIMIN":
            tabreponse[4]++; 
            break; 
        
        default: 
            console.log("Selectionner une reponse"); 

    }
    switch (q5)
    {
        case "TAEHYUNG": 
            tabreponse[5]++; 
            break; 

        case "JIMIN": 
            tabreponse[4]++;
         
            break; 
        
        case "JUNGKOOK": 
            tabreponse[6]++; 
            break; 
        
        case "JHOPE":
            tabreponse[3]++; 
            break; 
        
        default: 
            console.log("Selectionner une reponse"); 

    }
    switch (q6)
    {
        case "JUNGKOOK": 
            tabreponse[6]++; 
            break; 

        case "NAMJOON": 
            tabreponse[0]++;
         
            break; 
        
        case "JHOPE": 
            tabreponse[3]++; 
            break; 
        
        case "JIN":
            tabreponse[1]++; 
            break; 
        
        default: 
            console.log("Selectionner une reponse"); 

    }
    switch (q7)
    {
        case "JIN": 
            tabreponse[1]++; 
            break; 

        case "YOONGI": 
            tabreponse[2]++;
         
            break; 
        
        case "TAEHYUNG": 
            tabreponse[5]++; 
            break; 
        
        case "JIMIN":
            tabreponse[4]++; 
            break; 
        
        default: 
            console.log("Selectionner une reponse"); 

    }


    var max=0; 
    for(let i=1; i<7; i++)
    {
        if(tabreponse[max]<tabreponse[i])
        {
            max=i; 
        }
    }


    switch(max)
    {
        case 0: 
            alert("Tu es Namjoon Bravo! Intelligent(e), sensible, fan d'art et ami de la nature");
            break;
        case 1: 
            alert("Tu es Jin Bravo! Magnifique et tu le sais tu es aussi très drole et talentueux");
            break;
        
        case 2: 
            alert("Tu es Yoongi Bravo! D'un naturel calme et doué(e) d'une grande intelligence emotionnelle tu es THE BEST");
            break; 

        case 3: 
            alert("Tu es J-Hope Bravo! Un rayon de soleil dans la vie de tes proches mais très organisé et sérieux");
            break;

        case 4: 
            alert("Tu es Jimin Bravo! La  douceur et le charme incarné tu es perfectioniste et social");
            break;
        
        case 5: 
            alert("Tu es Taehyung Bravo! Vous avez le coeur sur la main, un melange parfait de douceur et de fermeté");
            break;

        case 6: 
            alert("Tu es Jungkook Bravo! Vous êtes doués mais vous travaillés dur, avec un coeur qui deborde d'amour");
            break;
    }
}